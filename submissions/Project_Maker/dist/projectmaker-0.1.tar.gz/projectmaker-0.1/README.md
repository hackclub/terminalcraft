# ProjectMaker
 A CLI tool that eases your project creation process
