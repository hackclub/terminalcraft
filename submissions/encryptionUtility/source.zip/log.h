#ifndef LOG_H
#define LOG_H

void printTitle();
void clear();

#endif // LOG_H
