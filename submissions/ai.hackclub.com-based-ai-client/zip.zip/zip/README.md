# Terminal ai
the goal for this is for it to be an ai that will help you in the terminal to debug things and that will work without a gui so that you can even use when debugging things like raspberry pis with no desktop environment.

This uses the [ai.hackclub.com](https://ai.hackclub.com) api

it currently runs llama 3.3 70b versatile