# CLI-multiplayer
to run type in command prompt : Start_2PlayerGames
it will contain multiple 2 player games designed for tournament style matches 
you need to follow the syntax provided if square brackets type it in square brackets or ()
you can enter the games repeatedly [1,2,2,3,5,1]
before each game you would be told what the next game will be
in some games base time or minnimum time given to each player will be set which will decrease throughout the game

## Installation
This package requires Python 3.9. or more recent 
If you don't have Python installed, download it from [python.org](https://www.python.org/downloads/).

### Windows Users:
- Download and install Python from the link above.
- Make sure to check **"Add Python to PATH"** during installation.

### Mac/Linux Users:
- Run: `brew install python` (Mac) or `sudo apt install python3` (Linux).

